/* NoTodoEncaja Studio – browser editor. No subscription, no subtitles. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const state = {
    projectId: null, assets: [], scenes: [], audioId: '', selected: 0,
    resolution: '720p', transition: 'cut', autoSync: true,
    playing: false, currentTime: 0, currentPreviewIndex: -1,
    lastTick: 0, jobTimer: null
  };
  const els = {
    gallery: $('assetGallery'), timeline: $('timeline'), inspector: $('inspector'), audio: $('playerAudio'),
    img: $('previewImage'), previewEmpty: $('previewEmpty'), stage: $('previewStage')
  };
  let toastTimeout;

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }
  function formatTime(seconds) {
    let n = Math.max(0, Math.floor(Number(seconds) || 0));
    return String(Math.floor(n / 60)).padStart(2,'0') + ':' + String(n % 60).padStart(2,'0');
  }
  function toast(message, isError = false) {
    const box = $('toast'); box.textContent = message;
    box.classList.toggle('error', isError); box.classList.add('show');
    clearTimeout(toastTimeout); toastTimeout = setTimeout(() => box.classList.remove('show'), 4500);
  }
  async function api(path, options = {}) {
    const result = await fetch(path, options);
    if (!result.ok) {
      let msg = `Error ${result.status}`;
      try { let body = await result.json(); msg = typeof body.detail === 'string' ? body.detail : msg; } catch (_e) {}
      throw new Error(msg);
    }
    return await result.json();
  }
  function persist() {
    if (!state.projectId) return;
    localStorage.setItem('nte_studio_session', JSON.stringify({projectId:state.projectId,
      scenes:state.scenes, audioId:state.audioId, resolution:state.resolution,
      transition:state.transition, autoSync:state.autoSync}));
  }
  function restoreSettings(data) {
    state.scenes = Array.isArray(data.scenes) ? data.scenes : [];
    state.audioId = data.audioId || '';
    state.resolution = data.resolution || '720p'; state.transition = data.transition || 'cut';
    state.autoSync = data.autoSync !== false;
    $('resolution').value = state.resolution; $('transition').value = state.transition;
    $('autoSync').checked = state.autoSync;
  }
  async function startNewProject(isDemo = false) {
    if (state.playing) pause();
    const result = await api(isDemo ? '/api/demo' : '/api/projects', {method:'POST'});
    state.projectId = result.id; state.assets = result.assets || []; state.currentTime = 0;
    state.scenes = []; state.selected = 0; state.audioId = '';
    state.currentPreviewIndex = -1;
    if (isDemo) {
      state.scenes = state.assets.filter(a => a.kind === 'image').map((item,i) => ({
        asset_id:item.id, title: ['La señal','El archivo','La anomalía','La revelación'][i] || `Escena ${i+1}`,
        duration:4, motion:['zoom_in','pan_right','zoom_out','pan_left'][i % 4]}));
      const audio = state.assets.find(a=>a.kind === 'audio');
      state.audioId = audio?.id || '';
      toast('Demo cargada: 4 imágenes diferentes y narración de prueba.');
    }
    bindAudio(); persist(); paint();
  }
  function selectedAudio() { return state.assets.find(x=>x.id === state.audioId && x.kind === 'audio'); }
  function asset(id) { return state.assets.find(x=>x.id === id); }
  function bindAudio() {
    const a = selectedAudio();
    els.audio.pause(); els.audio.src = a ? a.url : '';
    els.audio.load(); state.playing = false; state.currentTime = 0;
    $('playButton').textContent = '▶';
  }
  function durations() {
    if (!state.scenes.length) return [];
    const raw = state.scenes.map(x=>Math.max(1,Number(x.duration)||4));
    const audioLength = selectedAudio()?.duration;
    if (!state.autoSync || !audioLength) return raw;
    const overlap = state.transition === 'dissolve' ? .32 * (raw.length - 1) : 0;
    const budget = audioLength + overlap;
    const total = raw.reduce((a,b)=>a+b,0);
    return raw.map(n => n / total * budget);
  }
  function totalDuration() {
    const d = durations();
    return Math.max(0,d.reduce((a,b)=>a+b,0) - (state.transition === 'dissolve' ? Math.max(0,d.length-1) * .32 : 0));
  }
  function positionToScene(position) {
    const d = durations(); let begin = 0;
    for (let i=0; i < d.length; i++) {
      if (position < begin + d[i] || i===d.length-1)
        return {index:i, local:Math.max(0,position-begin), length:d[i]};
      begin += d[i] - (state.transition === 'dissolve' ? .32 : 0);
    }
    return {index:-1,local:0,length:0};
  }
  function previewAt(position, resetAnimation = false) {
    const total = totalDuration(); state.currentTime = Math.min(Math.max(0,position), total);
    $('currentTime').textContent = formatTime(state.currentTime);
    $('totalTime').textContent = formatTime(total);
    $('seekBar').value = total > 0 ? Math.round(state.currentTime / total * 1000) : 0;
    if (!state.scenes.length) return;
    const loc = positionToScene(state.currentTime);
    const scene = state.scenes[loc.index]; const file = asset(scene.asset_id);
    if (!file) return;
    if (loc.index !== state.currentPreviewIndex || resetAnimation) {
      state.currentPreviewIndex = loc.index;
      els.img.src = file.url; els.img.style.display = 'block'; els.previewEmpty.style.display = 'none';
      els.img.className = scene.motion + ' animate';
      els.img.style.setProperty('--scene-duration', `${loc.length}s`);
      els.img.style.animation = 'none'; void els.img.offsetWidth;
      els.img.style.animation = '';
      els.img.style.animationDelay = `${-loc.local}s`;
      els.img.style.animationPlayState = state.playing ? 'running' : 'paused';
      $('previewSceneName').textContent = `ESCENA ${String(loc.index+1).padStart(2,'0')} / ${escapeHtml(scene.title).slice(0,34)}`;
      $('previewMotion').textContent = {zoom_in:'ACERCAMIENTO',zoom_out:'ALEJAMIENTO',pan_left:'DESPLAZAMIENTO IZQUIERDA',pan_right:'DESPLAZAMIENTO DERECHA',static:'PLANO FIJO'}[scene.motion] || '—';
      document.querySelectorAll('.timeline-scene').forEach((el,i)=>el.classList.toggle('playing',i===loc.index));
    }
  }
  function pause() { state.playing=false; els.audio.pause(); $('playButton').textContent='▶'; els.img.style.animationPlayState='paused'; }
  function play() {
    if (!state.scenes.length) return toast('Primero añade una escena.', true);
    const total = totalDuration();
    if (state.currentTime >= total-.05) {state.currentTime=0; previewAt(0,true);}
    state.playing=true; $('playButton').textContent='❚❚';
    els.img.style.animationPlayState='running';
    if (selectedAudio()) {
      els.audio.currentTime = state.currentTime;
      els.audio.play().catch(()=>{pause(); toast('El navegador no pudo reproducir el audio.', true);});
    }
    state.lastTick = performance.now(); requestAnimationFrame(tick);
  }
  function tick(time) {
    if (!state.playing) return;
    const elapsed = Math.min((time - state.lastTick)/1000,.25); state.lastTick = time;
    const where = selectedAudio() ? els.audio.currentTime : state.currentTime + elapsed;
    previewAt(where);
    if (where >= totalDuration()-.04 || (selectedAudio() && els.audio.ended)) pause();
    else requestAnimationFrame(tick);
  }
  function paintGallery() {
    const images = state.assets.filter(a=>a.kind === 'image');
    $('assetCount').textContent = `${images.length} imágenes`;
    els.gallery.innerHTML = images.length ? images.map((file,i)=>{
      const used=state.scenes.some(s=>s.asset_id===file.id);
      return `<button class="asset-tile ${used?'used':''}" data-add="${file.id}" title="${used?'Imagen ya incluida':'Añadir a escenas'}" ${used?'disabled':''}>
        <img src="${file.url}" loading="lazy" alt="Recurso ${i+1}" />
        <span class="asset-plus">${used?'✓':'+'}</span><span class="asset-label">${escapeHtml(file.name)}</span></button>`;
    }).join('') : `<p class="empty-gallery">Todavía no hay imágenes. Comienza cargando recursos o abre la demostración.</p>`;
  }
  function paintTimeline() {
    const d=durations(); const tot=totalDuration();
    $('sceneCount').textContent = `(${state.scenes.length})`;
    $('timelineMiddle').textContent=formatTime(tot/2); $('timelineEnd').textContent=formatTime(tot);
    $('timelineSummary').textContent = `${state.scenes.length} escenas · ${tot.toFixed(1)} segundos`;
    if (!state.scenes.length) {
      els.timeline.innerHTML='<div class="no-scenes"><span>▤</span> Tus escenas aparecerán aquí en orden de reproducción.</div>';return;
    }
    els.timeline.innerHTML=state.scenes.map((scene,i)=>{
      const file=asset(scene.asset_id);const grow=Math.max(1,d[i]/3);
      return `<button class="timeline-scene ${i===state.selected?'selected':''}" data-select="${i}" style="flex-grow:${grow}" title="Seleccionar escena ${i+1}">
        <img src="${file?.url||''}" alt="Escena ${i+1}" /><span class="segment-no">${String(i+1).padStart(2,'0')}</span>
        <span class="segment-info"><span>${escapeHtml(scene.title)}</span><span>${d[i].toFixed(1)} s</span></span></button>`;
    }).join('');
  }
  function paintInspector() {
    const scene = state.scenes[state.selected];
    if (!scene) {els.inspector.innerHTML='<p class="muted small">Añade y selecciona una escena para ajustar sus detalles.</p>';return;}
    els.inspector.innerHTML=`<div class="scene-number">TOMA ${String(state.selected+1).padStart(2,'0')} / ${String(state.scenes.length).padStart(2,'0')}</div>
      <label>Nombre de la escena<input id="editTitle" type="text" maxlength="90" value="${escapeHtml(scene.title)}" placeholder="Ej. El hallazgo" /></label>
      <label>Peso temporal (${state.autoSync && selectedAudio() ? 'ajuste proporcional':'segundos'})<input id="editDuration" type="number" step="0.5" min="1" max="120" value="${scene.duration}" /></label>
      <label>Movimiento de cámara<select id="editMotion">
      <option value="zoom_in" ${scene.motion==='zoom_in'?'selected':''}>Acercamiento lento</option>
      <option value="zoom_out" ${scene.motion==='zoom_out'?'selected':''}>Alejamiento lento</option>
      <option value="pan_left" ${scene.motion==='pan_left'?'selected':''}>Panorámica a la izquierda</option>
      <option value="pan_right" ${scene.motion==='pan_right'?'selected':''}>Panorámica a la derecha</option>
      <option value="static" ${scene.motion==='static'?'selected':''}>Imagen fija</option></select></label>
      <div class="scene-actions"><button id="moveLeft" title="Mover a la izquierda">← Anterior</button><button id="moveRight" title="Mover a la derecha">Siguiente →</button><button id="deleteScene" class="delete" title="Quitar escena">✕</button></div>`;
  }
  function paint() {
    paintGallery(); paintTimeline(); paintInspector();
    $('resolutionChip').textContent=state.resolution==='720p'?'1280 × 720':'1920 × 1080';
    const a=selectedAudio(); $('narrationText').textContent=a?`${a.name} · ${formatTime(a.duration)}`:'Importa tu archivo de Revoicer (.mp3, .wav, .m4a)';
    $('audioUploadLabel').textContent = a ? '↻ Cambiar voz' : '+ Subir voz';
    if (!state.scenes.length) {
      els.img.style.display='none'; els.previewEmpty.style.display='flex'; state.currentPreviewIndex=-1;
      $('previewSceneName').textContent='SIN ESCENAS';$('previewMotion').textContent='—';
    }
    previewAt(Math.min(state.currentTime,totalDuration()),true);
    $('saveStatus').innerHTML='<span class="live-dot"></span> Edición guardada';
  }
  function nearDuplicateHash(a,b) {
    if (!a || !b) return false;
    // JavaScript BigInt handles the full 64-bit fingerprint.
    let n=BigInt('0x'+a)^BigInt('0x'+b), count=0;
    while(n){n&=n-1n;count++;}
    return count<=3;
  }
  function addScene(id) {
    if (state.scenes.length>=40) return toast('Máximo 40 escenas por render.',true);
    if (state.scenes.some(s=>s.asset_id===id)) return toast('Esa imagen ya está en la secuencia. Usa otra distinta.',true);
    const file=asset(id);if (!file) return;
    if (state.scenes.some(s=>nearDuplicateHash(file.fingerprint,asset(s.asset_id)?.fingerprint)))
      return toast('Esta imagen se parece demasiado a otra escena. Selecciona una diferente.',true);
    pause();state.scenes.push({asset_id:id,title:`Escena ${state.scenes.length+1}`,duration:4,motion:['zoom_in','pan_right','zoom_out','pan_left'][state.scenes.length%4]});
    state.selected=state.scenes.length-1;persist();paint();
  }
  function selectScene(i) {
    if (i<0 || i>=state.scenes.length)return;
    pause();state.selected=i;
    let time=0;const d=durations();for (let j=0;j<i;j++)time+=d[j]-(state.transition==='dissolve'?.32:0);
    if (selectedAudio())els.audio.currentTime=time;
    previewAt(time,true);paintTimeline();paintInspector();
  }
  async function upload(files, kind) {
    if (!files?.length) return;
    if (!state.projectId) return toast('Creando el proyecto. Intenta de nuevo.', true);
    let ok=0;
    for (const file of Array.from(files)) {
      try {
        toast(`Subiendo ${file.name}...`);
        const form = new FormData();form.append('file',file);
        const record=await api(`/api/projects/${state.projectId}/upload?kind=${kind}`,{method:'POST',body:form});
        state.assets.push(record); if (kind==='audio'){pause();state.audioId=record.id;bindAudio();} ok++;
      } catch(e) {toast(`${file.name}: ${e.message}`,true);}
    }
    persist();paint();if(ok)toast(`${ok} ${kind==='image'?'imagen(es)':'archivo(s) de audio'} cargado(s).`);
  }
  async function exportMovie() {
    if (!state.projectId || !state.scenes.length) return toast('Agrega imágenes a la línea de tiempo.',true);
    if (!selectedAudio()) return toast('Para exportar necesitas subir una narración.',true);
    if (state.autoSync && selectedAudio().duration < state.scenes.length) return toast('La narración es demasiado corta para tantas escenas.',true);
    const modal=$('renderModal');modal.classList.remove('hidden');$('renderTitle').textContent='Preparando tu documental';
    $('renderStage').textContent='Validando escenas...';$('renderProgress').style.width='2%';$('renderPercent').textContent='2%';
    $('downloadLink').classList.add('hidden');$('renderHint').textContent='Mantén abierta esta página hasta finalizar.';
    try {
      const request={audio_id:state.audioId,scenes:state.scenes,resolution:state.resolution,
        transition:state.transition,auto_sync:state.autoSync};
      const job=await api(`/api/projects/${state.projectId}/render`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(request)});
      pollJob(job.id);
    }catch(e){$('renderTitle').textContent='No se pudo exportar';$('renderStage').textContent=e.message;toast(e.message,true);}
  }
  async function pollJob(jobId) {
    try {
      const job=await api(`/api/jobs/${jobId}`);
      $('renderProgress').style.width=`${job.progress}%`; $('renderPercent').textContent=`${job.progress}%`;
      $('renderStage').textContent=job.stage;
      if(job.status==='completed') {
        $('renderTitle').textContent='Tu documental está listo';
        const link=$('downloadLink');link.href=job.download_url;link.classList.remove('hidden');
        $('renderHint').textContent=`Exportado a ${state.resolution} · sin subtítulos incrustados`;
        return;
      }
      if(job.status==='failed'){ $('renderTitle').textContent='Error de renderizado';toast('No se pudo renderizar: '+job.stage,true);return;}
      state.jobTimer=setTimeout(()=>pollJob(jobId),1100);
    }catch(e){$('renderStage').textContent='No se pudo consultar el render: '+e.message;}
  }
  function bindEvents() {
    $('imageUpload').addEventListener('change',event=>{upload(event.target.files,'image');event.target.value='';});
    $('audioUpload').addEventListener('change',event=>{upload(event.target.files,'audio');event.target.value='';});
    const drop=$('dropBox');
    ['dragenter','dragover'].forEach(name=>drop.addEventListener(name,event=>{event.preventDefault();drop.classList.add('drag-over');}));
    ['dragleave','drop'].forEach(name=>drop.addEventListener(name,event=>{event.preventDefault();drop.classList.remove('drag-over');}));
    drop.addEventListener('drop',event=>upload([...event.dataTransfer.files].filter(f=>/image\//.test(f.type)),'image'));
    drop.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();$('imageUpload').click();}});
    els.gallery.addEventListener('click',event=>{const btn=event.target.closest('[data-add]');if(btn)addScene(btn.dataset.add);});
    els.timeline.addEventListener('click',event=>{const btn=event.target.closest('[data-select]');if(btn)selectScene(Number(btn.dataset.select));});
    els.inspector.addEventListener('change',event=>{
      const scene=state.scenes[state.selected];if(!scene)return;
      if(event.target.id==='editTitle')scene.title=event.target.value.trim()||`Escena ${state.selected+1}`;
      if(event.target.id==='editMotion')scene.motion=event.target.value;
      if(event.target.id==='editDuration')scene.duration=Math.min(120,Math.max(1,Number(event.target.value)||4));
      pause();persist();paint();
    });
    els.inspector.addEventListener('click',event=>{
      const id=event.target.id;const index=state.selected;
      if(id==='deleteScene'){pause();state.scenes.splice(index,1);state.selected=Math.max(0,index-1);}
      else if(id==='moveLeft' && index>0){pause();[state.scenes[index-1],state.scenes[index]]=[state.scenes[index],state.scenes[index-1]];state.selected--;}
      else if(id==='moveRight' && index<state.scenes.length-1){pause();[state.scenes[index+1],state.scenes[index]]=[state.scenes[index],state.scenes[index+1]];state.selected++;}
      else return;
      persist();paint();
    });
    $('resolution').addEventListener('change',event=>{state.resolution=event.target.value;persist();paint();});
    $('transition').addEventListener('change',event=>{state.transition=event.target.value;pause();persist();paint();});
    $('autoSync').addEventListener('change',event=>{state.autoSync=event.target.checked;pause();persist();paint();});
    $('playButton').addEventListener('click',()=>state.playing?pause():play());
    $('seekBar').addEventListener('input',event=>{
      pause();const time=Number(event.target.value)/1000*totalDuration();
      if(selectedAudio())els.audio.currentTime=time;previewAt(time,true);
    });
    $('muteButton').addEventListener('click',()=>{els.audio.muted=!els.audio.muted;$('muteButton').textContent=els.audio.muted?'♩':'♫';});
    els.audio.addEventListener('ended',pause);
    $('exportButton').addEventListener('click',exportMovie);
    $('closeModal').addEventListener('click',()=>$('renderModal').classList.add('hidden'));
    $('newProject').addEventListener('click',async()=>{if(!confirm('¿Crear un proyecto nuevo? El proyecto anterior permanece guardado en este navegador.'))return;try{await startNewProject();toast('Proyecto nuevo creado.');}catch(e){toast(e.message,true);}});
    $('loadDemo').addEventListener('click',async()=>{try{await startNewProject(true);}catch(e){toast(e.message,true);}});
    document.addEventListener('keydown',event=>{if(event.code==='Space' && !['INPUT','SELECT','TEXTAREA','BUTTON'].includes(document.activeElement.tagName)){event.preventDefault();state.playing?pause():play();}});
  }
  async function init() {
    bindEvents();
    try {
      const old=JSON.parse(localStorage.getItem('nte_studio_session')||'null');
      if(old?.projectId) {
        const doc=await api(`/api/projects/${old.projectId}`);
        state.projectId=doc.id;state.assets=doc.assets||[];restoreSettings(old);
        const all=new Set(state.assets.map(a=>a.id));
        state.scenes=state.scenes.filter(s=>all.has(s.asset_id));
        if(!all.has(state.audioId))state.audioId='';
        bindAudio();paint();return;
      }
    } catch(_e) {localStorage.removeItem('nte_studio_session');}
    try {await startNewProject();}catch(e){toast('No se pudo iniciar el servidor: '+e.message,true);}
  }
  init();
})();

# NoTodoEncaja Studio · Editor documental (MVP 0.1)

**Aplicación real para montar videos MP4 desde fotografías + una pista de narración.** Interfaz y documentación en español. Proyecto independiente, desarrollado con FastAPI y FFmpeg. No copia código de Adobe, Fliki ni CapCut.

## Funcionalidades incluidas

- Arrastra o carga imágenes JPG/PNG/WEBP; selecciona una imagen diferente para cada toma (bloquea duplicados y fotografías casi idénticas mediante huellas visuales).
- Importa voz en off de Revoicer u otra fuente en MP3, WAV, M4A, AAC, OGG o FLAC.
- Ajusta orden, título interno, duración/peso temporal y cinco estilos de movimiento de cámara.
- Vista previa de escenas con animación en navegador y reproducción de la voz.
- Sincronización automática de las duraciones visuales con la pista de audio, o duraciones manuales.
- Transiciones de corte y fundido cruzado (disolvencia de 0,32 segundos).
- Exportación a **MP4 H.264 + AAC**, 720p o 1080p, 25 fps.
- **Nunca incrusta subtítulos**; los títulos escritos en el editor son etiquetas internas.
- Un ejemplo funcional con 4 imágenes originales y una voz sintética de prueba, usando el botón **Cargar demo**.
- Proyectos guardados en disco; edición en el navegador guardada localmente.

## Inicio rápido en Windows

1. Instala **Python 3.11 o más reciente** desde https://www.python.org/downloads/ (activa *Add Python to PATH*).
2. Instala **FFmpeg** desde https://ffmpeg.org/download.html y asegúrate de que `ffmpeg` y `ffprobe` están en el PATH.
3. Descomprime `NoTodoEncaja_Studio_MVP.zip` y ejecuta `start_windows.bat`.
4. Cuando aparezca el mensaje *Uvicorn running*, abre **http://127.0.0.1:8000** en tu navegador.
5. Selecciona **Cargar demo** para validar el proceso. Después, pulsa **+ Nuevo** para tu documental.

### Inicio rápido en macOS / Linux

Instala Python 3.11+ y FFmpeg. Desde la carpeta extraída:

```bash
bash start.sh
```

Abre **http://127.0.0.1:8000**. No necesitas ninguna cuenta de pago.

## Ejecutar en Docker (incluye FFmpeg)

```bash
docker build -t nte-studio .
docker run --rm -p 8000:8000 -e STUDIO_USER=studio -e STUDIO_PASSWORD=CAMBIA_ESTA_CLAVE -v nte-studio-data:/app/data/projects nte-studio
```

Después abre **http://127.0.0.1:8000**. Para acceso remoto, publica el contenedor detrás de HTTPS y contraseña. El contenedor puede utilizarse en proveedores compatibles con Docker; **esta entrega no incluye hosting ni una URL pública**. Si lo publicas en un servicio con disco efímero, los recursos pueden perderse al reiniciar; monta un volumen persistente.

**Seguridad:** cambia la contraseña de ejemplo, utiliza HTTPS y no expongas el servidor públicamente sin autenticación. No incluye multiusuario, política de cuotas, antivirus ni un servicio de almacenamiento externo; son tareas de una versión de producción.

## Flujo para el canal

1. Exporta el audio final desde Revoicer (`.mp3` preferiblemente).
2. Carga una imagen diferente para cada escena; evita ilustraciones genéricas sin relación con la historia.
3. Ordena las escenas, nómbralas para facilitar el montaje y elige movimientos de cámara.
4. Carga la voz y deja activado **Ajustar escenas a la voz** para sincronizar automáticamente la duración de toda la secuencia.
5. Escoge *Disolvencia* o *Corte*, selecciona 720p (rápido) o 1080p (mayor resolución) y haz clic en **Exportar MP4**.
6. Descarga el archivo resultante para YouTube; no lleva subtítulos integrados.

## Limitaciones actuales

- El motor trabaja con **imágenes estáticas animadas**, no genera automáticamente clips cinematográficos mediante un modelo de video IA.
- No es un clon completo de Adobe Premiere: sin pista musical independiente, sin recorte/trimming de video, sin subtítulos editables, sin máscaras, sin efectos de partículas ni mezclador multitrack.
- Los rótulos y títulos son información del editor, no aparecen en el MP4.
- La vista previa es aproximada: en la exportación final, FFmpeg aplica los movimientos precisos y el fundido cruzado.
- La interfaz conserva **un proyecto activo por navegador**; los proyectos anteriores quedan en la carpeta `data/projects`, pero aún no hay selector de proyectos ni función de eliminación.
- Se permite un máximo de 40 escenas por render y 15 minutos por narración, para acotar recursos. La exportación a 1080p y muchas tomas consume CPU.
- Cualquier archivo de video publicado en un servidor sigue estando sujeto a las licencias de sus imágenes, audio y elementos usados.

## API y arquitectura

- `app.py`: API HTTP, carga validada de archivos, trabajos de render en cola simple, proyectos y exportaciones.
- `renderer.py`: duración de audio, movimiento Ken Burns, composición de escenas y multiplexado H.264/AAC mediante FFmpeg.
- `static/`: HTML, CSS y JavaScript del editor web.
- `demo_assets/`: cuatro imágenes de prueba originales y narración sintética de prueba (no usar como documental comercial final).
- `make_demo_assets.py`: generador opcional de los recursos de prueba; requiere NumPy y un sintetizador `espeak` instalados. **No es necesario ejecutarlo para usar la aplicación**, los recursos ya están incluidos.
- `tests/`: pruebas funcionales del backend.

API disponible en `http://127.0.0.1:8000/api/docs`. Motor y archivos se ejecutan en tu propio equipo o servidor, sin conexión obligatoria con servicios de IA.

## Próximos hitos propuestos

1. Alineación **frase por frase** (detección de pausas / transcripción con voz), en lugar de la actual distribución proporcional.
2. Análisis semántico de guion y generador/selector de storyboard con control antirepetición de escenas similares, no solo archivos idénticos.
3. Clips de video y animación generativa opcional, con motor integrable y presupuestos de créditos claros.
4. Mezcla de música y efectos, biblioteca reutilizable, guardado completo de proyectos y publicación web con acceso seguro.

---

**Estado:** prototipo MVP funcional, no un editor comercial listo para producción masiva.

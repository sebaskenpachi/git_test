"""NoTodoEncaja Studio - API server and lightweight project storage."""
from __future__ import annotations

import base64
import json
import os
import secrets
import re
import shutil
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from PIL import Image, ImageOps, UnidentifiedImageError

from renderer import RenderScene, probe_duration, render_video

ROOT = Path(__file__).resolve().parent
STORE = Path(os.environ.get("STUDIO_DATA_DIR", str(ROOT / "data" / "projects"))).resolve()
DEMO = ROOT / "demo_assets"
STORE.mkdir(parents=True, exist_ok=True)
UUID_RE = re.compile(r"^[0-9a-f]{32}$")
IMAGE_TYPES = {".jpg", ".jpeg", ".png", ".webp"}
AUDIO_TYPES = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"}
JOBS: dict[str, dict] = {}
JOBS_LOCK = threading.Lock()
RENDER_LOCK = threading.Lock()

app = FastAPI(title="NoTodoEncaja Studio", version="0.1.0", docs_url="/api/docs")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")


@app.middleware("http")
async def optional_private_access(request, call_next):
    """Set STUDIO_PASSWORD and optionally STUDIO_USER to secure a web deployment."""
    from fastapi.responses import Response
    password = os.environ.get("STUDIO_PASSWORD", "")
    if password:
        token = request.headers.get("authorization", "")
        expected = base64.b64encode((os.environ.get("STUDIO_USER", "studio") + ":" + password).encode()).decode()
        if not secrets.compare_digest(token, "Basic " + expected):
            return Response("Autenticación requerida", status_code=401,
                            headers={"WWW-Authenticate": 'Basic realm="NoTodoEncaja Studio"'})
    return await call_next(request)


def visual_fingerprint(image: Image.Image) -> str:
    """64-bit difference hash to catch resized/re-encoded near-duplicate stills."""
    tiny = ImageOps.grayscale(image).resize((9, 8), Image.Resampling.LANCZOS)
    pix = list(tiny.tobytes())
    bits = 0
    for row in range(8):
        for col in range(8):
            bits = (bits << 1) | (1 if pix[row*9 + col] > pix[row*9 + col+1] else 0)
    return f"{bits:016x}"


def near_duplicate(a: str | None, b: str | None) -> bool:
    return bool(a and b and (int(a, 16) ^ int(b, 16)).bit_count() <= 3)


def valid_id(value: str) -> str:
    if not UUID_RE.fullmatch(value or ""):
        raise HTTPException(400, "Identificador inválido")
    return value


def project_dir(project_id: str) -> Path:
    directory = STORE / valid_id(project_id)
    if not directory.is_dir():
        raise HTTPException(404, "Proyecto no encontrado")
    return directory


def manifest_path(project_id: str) -> Path:
    return project_dir(project_id) / "manifest.json"


def read_manifest(project_id: str) -> dict:
    return json.loads(manifest_path(project_id).read_text(encoding="utf-8"))


def save_manifest(project_id: str, doc: dict) -> None:
    dest = manifest_path(project_id)
    temp = dest.with_suffix(".tmp")
    temp.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(dest)


def make_project(title: str = "Mi documental") -> dict:
    project_id = uuid.uuid4().hex
    directory = STORE / project_id
    (directory / "assets").mkdir(parents=True)
    (directory / "exports").mkdir()
    doc = {"id": project_id, "name": title, "created": datetime.now(timezone.utc).isoformat(), "assets": []}
    save_manifest(project_id, doc)
    return doc


@app.get("/")
def index():
    return FileResponse(ROOT / "static" / "index.html")


@app.get("/api/health")
def health():
    return {"status": "ok", "engine": "ffmpeg", "version": "0.1.0"}


@app.post("/api/projects")
def create_project():
    return make_project()


@app.get("/api/projects/{project_id}")
def get_project(project_id: str):
    return read_manifest(project_id)


async def ingest_file(project_id: str, file: UploadFile, kind: str) -> dict:
    project = project_dir(project_id)
    ext = Path(file.filename or "").suffix.lower()
    if kind == "image" and ext not in IMAGE_TYPES:
        raise HTTPException(400, "Imagen inválida (JPG, PNG o WEBP)")
    if kind == "audio" and ext not in AUDIO_TYPES:
        raise HTTPException(400, "Audio inválido (MP3, WAV, M4A, AAC, OGG o FLAC)")
    if kind not in {"image", "audio"}:
        raise HTTPException(400, "Tipo de recurso inválido")
    identifier = uuid.uuid4().hex
    target = project / "assets" / (identifier + (".jpg" if kind == "image" else ext))
    incoming = project / "assets" / (identifier + ".incoming")
    cap = 18 * 1024 * 1024 if kind == "image" else 120 * 1024 * 1024
    nbytes = 0
    try:
        with incoming.open("wb") as out:
            while True:
                part = await file.read(1024 * 1024)
                if not part:
                    break
                nbytes += len(part)
                if nbytes > cap:
                    raise HTTPException(413, "Archivo excede el límite permitido")
                out.write(part)
        if not nbytes:
            raise HTTPException(400, "Archivo vacío")
        duration = None
        fingerprint = None
        if kind == "image":
            try:
                with Image.open(incoming) as raw:
                    raw.verify()
                with Image.open(incoming) as raw:
                    im = ImageOps.exif_transpose(raw).convert("RGB")
                    if im.width < 300 or im.height < 200 or im.width * im.height > 65000000:
                        raise HTTPException(400, "Imagen demasiado pequeña o excesivamente grande")
                    im.thumbnail((3200, 3200), Image.Resampling.LANCZOS)
                    fingerprint = visual_fingerprint(im)
                    im.save(target, quality=91, optimize=True)
            except (UnidentifiedImageError, OSError) as exc:
                raise HTTPException(400, "El archivo no contiene una imagen válida") from exc
        else:
            shutil.move(incoming, target)
            try:
                duration = probe_duration(target)
                if duration > 900:
                    raise HTTPException(400, "Máximo 15 minutos de audio")
            except (ValueError, RuntimeError, KeyError) as exc:
                raise HTTPException(400, "No se pudo leer el audio") from exc
        record = {"id": identifier, "kind": kind, "name": Path(file.filename or kind).name[:110],
                  "url": f"/api/projects/{project_id}/assets/{identifier}",
                  "duration": round(duration, 2) if duration else None, "fingerprint": fingerprint}
        doc = read_manifest(project_id)
        doc["assets"].append(record)
        save_manifest(project_id, doc)
        return record
    finally:
        incoming.unlink(missing_ok=True)
        # For rejected / failed images or audio, a leftover file should not remain.
        # Successful files are deliberately kept.


@app.post("/api/projects/{project_id}/upload")
async def upload(project_id: str, file: UploadFile = File(...), kind: Literal["image", "audio"] = "image"):
    return await ingest_file(project_id, file, kind)


@app.get("/api/projects/{project_id}/assets/{asset_id}")
def get_asset(project_id: str, asset_id: str):
    doc = read_manifest(project_id)
    identifier = valid_id(asset_id)
    record = next((x for x in doc["assets"] if x["id"] == identifier), None)
    if record is None:
        raise HTTPException(404, "Archivo no encontrado")
    matches = list((project_dir(project_id) / "assets").glob(identifier + ".*"))
    matches = [p for p in matches if p.suffix != ".incoming"]
    if not matches:
        raise HTTPException(404, "Archivo no encontrado")
    return FileResponse(matches[0])


class SceneSpec(BaseModel):
    asset_id: str
    title: str = Field(default="Escena", max_length=90)
    duration: float = Field(default=4, ge=1, le=120)
    motion: Literal["zoom_in", "zoom_out", "pan_left", "pan_right", "static"] = "zoom_in"


class RenderRequest(BaseModel):
    audio_id: str
    scenes: list[SceneSpec] = Field(min_length=1, max_length=40)
    resolution: Literal["720p", "1080p"] = "720p"
    transition: Literal["cut", "dissolve"] = "cut"
    auto_sync: bool = True


def asset_path(project_id: str, identifier: str, kind: str) -> Path:
    doc = read_manifest(project_id)
    matches = [x for x in doc["assets"] if x["id"] == valid_id(identifier) and x["kind"] == kind]
    if not matches:
        raise HTTPException(400, "Recurso no pertenece al proyecto o tiene un tipo inválido")
    for p in (project_dir(project_id) / "assets").glob(identifier + ".*"):
        if p.is_file() and not p.name.endswith(".incoming"):
            return p
    raise HTTPException(404, "Falta un recurso del proyecto")


def run_render(job_id: str, scenes: list[RenderScene], audio: Path, output: Path, settings: RenderRequest):
    def update(n: int, step: str):
        with JOBS_LOCK:
            JOBS[job_id].update(progress=n, stage=step)
    try:
        with RENDER_LOCK:
            meta = render_video(scenes=scenes, audio=audio, output=output,
                                resolution=settings.resolution, transition=settings.transition,
                                auto_sync=settings.auto_sync, progress=update)
        with JOBS_LOCK:
            JOBS[job_id].update(status="completed", progress=100, stage="Video terminado", result=meta)
    except Exception as exc:
        with JOBS_LOCK:
            JOBS[job_id].update(status="failed", stage=str(exc)[-450:])


@app.post("/api/projects/{project_id}/render")
def new_render(project_id: str, request: RenderRequest):
    project_dir(project_id)
    audio = asset_path(project_id, request.audio_id, "audio")
    images = [asset_path(project_id, scene.asset_id, "image") for scene in request.scenes]
    # Prevent accidental repeated frames/assets, the principal user requirement.
    if len({scene.asset_id for scene in request.scenes}) < len(request.scenes):
        raise HTTPException(400, "Hay imágenes repetidas. Usa un recurso diferente en cada escena")
    doc = read_manifest(project_id)
    records = {a["id"]: a for a in doc["assets"]}
    for i, scene in enumerate(request.scenes):
        for earlier in request.scenes[:i]:
            if near_duplicate(records[scene.asset_id].get("fingerprint"),
                              records[earlier.asset_id].get("fingerprint")):
                raise HTTPException(400, "Hay imágenes visualmente repetidas o casi idénticas. Reemplaza una")
    scenes = [RenderScene(image=path, duration=s.duration, motion=s.motion)
              for path, s in zip(images, request.scenes)]
    job_id = uuid.uuid4().hex
    output = project_dir(project_id) / "exports" / ("documental_" + job_id[:8] + ".mp4")
    with JOBS_LOCK:
        if sum(v["status"] in {"queued", "working"} for v in JOBS.values()) >= 3:
            raise HTTPException(429, "Hay renders en curso; prueba de nuevo al terminar")
        JOBS[job_id] = {"id": job_id, "project_id": project_id, "status": "working",
                        "progress": 2, "stage": "Preparando recursos", "download_url":
                        f"/api/projects/{project_id}/exports/{output.name}"}
    threading.Thread(target=run_render, args=(job_id, scenes, audio, output, request), daemon=True).start()
    return JOBS[job_id]


@app.get("/api/jobs/{job_id}")
def job_status(job_id: str):
    valid_id(job_id)
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if job is None:
            raise HTTPException(404, "Trabajo no encontrado")
        return dict(job)


@app.get("/api/projects/{project_id}/exports/{filename}")
def export_file(project_id: str, filename: str):
    if not re.fullmatch(r"documental_[0-9a-f]{8}\.mp4", filename):
        raise HTTPException(404, "Archivo no encontrado")
    path = project_dir(project_id) / "exports" / filename
    if not path.is_file():
        raise HTTPException(404, "Video no disponible")
    return FileResponse(path, media_type="video/mp4", filename=filename)


@app.post("/api/demo")
def create_demo():
    if not DEMO.is_dir():
        raise HTTPException(500, "No se encuentra el material de demostración")
    doc = make_project("Demostración · NoTodoEncaja")
    project = project_dir(doc["id"])
    examples = [(str(x), "image") for x in sorted(DEMO.glob("*.jpg"))]
    examples += [(str(x), "audio") for x in sorted(DEMO.glob("*.wav"))]
    for source, kind in examples:
        src = Path(source)
        identifier = uuid.uuid4().hex
        path = project / "assets" / (identifier + src.suffix)
        shutil.copy2(src, path)
        record = {"id": identifier, "kind": kind, "name": src.stem.replace("_", " ").title(),
                  "url": f"/api/projects/{doc['id']}/assets/{identifier}",
                  "duration": round(probe_duration(path), 2) if kind == "audio" else None,
                  "fingerprint": visual_fingerprint(Image.open(path)) if kind == "image" else None}
        doc["assets"].append(record)
    save_manifest(doc["id"], doc)
    return doc

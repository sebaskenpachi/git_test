"""NoTodoEncaja Studio – FFmpeg renderer.

Uses only media owned/provided by the project; no generative AI or paid API.
Narration is authoritative when auto_sync=True. No subtitles are burned in.
"""
from __future__ import annotations

import json
import math
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable


@dataclass(frozen=True)
class RenderScene:
    image: Path
    duration: float
    motion: str = "zoom_in"


MOTIONS = {"zoom_in", "zoom_out", "pan_left", "pan_right", "static"}
RESOLUTIONS = {"720p": (1280, 720), "1080p": (1920, 1080)}


def cmd_run(command: list[str], timeout: int = 3600) -> str:
    p = subprocess.run(command, text=True, capture_output=True, timeout=timeout)
    if p.returncode:
        raise RuntimeError((p.stderr or p.stdout)[-1600:])
    return p.stdout


def probe_duration(path: Path) -> float:
    raw = cmd_run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", str(path)], timeout=60)
    val = float(json.loads(raw)["format"]["duration"])
    if not math.isfinite(val) or val <= 0:
        raise ValueError("El archivo de audio no tiene una duración válida")
    return val


def effective_durations(scenes: list[RenderScene], narration_seconds: float, auto_sync: bool, transition: str, fps: int = 25) -> list[float]:
    if not scenes:
        raise ValueError("Se necesita al menos una escena")
    if len(scenes) > 40:
        raise ValueError("Máximo 40 escenas por render")
    if any(not math.isfinite(s.duration) or s.duration < 1 or s.duration > 120 for s in scenes):
        raise ValueError("Cada duración debe estar entre 1 y 120 segundos")
    overlap = 0.32 if transition == "dissolve" and len(scenes) > 1 else 0
    if auto_sync:
        target = narration_seconds + overlap * (len(scenes) - 1)
        if target < len(scenes) * 1.0:
            raise ValueError("Audio demasiado corto para el número de escenas; reduce la cantidad")
        weights = [s.duration for s in scenes]
        norm = sum(weights)
        lengths = [target * w / norm for w in weights]
        if min(lengths) < 0.48:
            raise ValueError("La distribución produce escenas demasiado cortas; ajusta sus duraciones")
    else:
        lengths = [s.duration for s in scenes]
    # Quantize lengths to video frames. Last segment absorbs up to a frame of discrepancy.
    frames = [max(1, round(x * fps)) for x in lengths]
    if auto_sync:
        target_frames = round((narration_seconds + overlap * (len(scenes) - 1)) * fps)
        frames[-1] += target_frames - sum(frames)
        if frames[-1] < fps // 2:
            raise ValueError("La última escena queda demasiado corta")
    return [f / fps for f in frames]


def scene_filter(width: int, height: int, duration: float, motion: str, fps: int) -> str:
    if motion not in MOTIONS:
        raise ValueError(f"Movimiento desconocido: {motion}")
    frames = max(1, round(duration * fps))
    # First normalize images without distortion: pad on near-black. Zoompan then adds subtle motion.
    # scale and crop to the aspect ratio, centered. scale=resolution*2 reduces zoom jitter.
    base = (f"scale={width*2}:{height*2}:force_original_aspect_ratio=increase,"
            f"crop={width*2}:{height*2},setsar=1")
    progress = f"on/{max(1, frames - 1)}"
    if motion == "zoom_in":
        z = f"1+0.075*({progress})"
        x = "iw/2-iw/zoom/2"
        y = "ih/2-ih/zoom/2"
    elif motion == "zoom_out":
        z = f"1.075-0.075*({progress})"
        x = "iw/2-iw/zoom/2"
        y = "ih/2-ih/zoom/2"
    elif motion == "pan_left":
        z = "1.075"
        x = f"(iw-iw/zoom)*(1-({progress}))"
        y = "ih/2-ih/zoom/2"
    elif motion == "pan_right":
        z = "1.075"
        x = f"(iw-iw/zoom)*({progress})"
        y = "ih/2-ih/zoom/2"
    else:
        z = "1"
        x = "0"
        y = "0"
    return (f"{base},zoompan=z='{z}':x='{x}':y='{y}':d={frames}:s={width}x{height}:fps={fps},"
            f"format=yuv420p")


def render_video(*, scenes: list[RenderScene], audio: Path, output: Path, resolution: str = "720p",
                 transition: str = "cut", auto_sync: bool = True,
                 progress: Callable[[int, str], None] | None = None, fps: int = 25) -> dict[str, Any]:
    if resolution not in RESOLUTIONS:
        raise ValueError("Resolución no soportada")
    if transition not in {"cut", "dissolve"}:
        raise ValueError("Transición no soportada")
    if not audio.exists() or any(not s.image.exists() for s in scenes):
        raise FileNotFoundError("Falta uno de los recursos multimedia")
    narration = probe_duration(audio)
    if narration > 900:
        raise ValueError("Máximo 15 minutos de narración por render")
    widths = RESOLUTIONS[resolution]
    lengths = effective_durations(scenes, narration, auto_sync, transition, fps)
    width, height = widths
    output.parent.mkdir(parents=True, exist_ok=True)
    tempdir = output.parent / (output.stem + "_intermediate")
    tempdir.mkdir(exist_ok=True)
    clips: list[Path] = []

    try:
        for idx, (scene, length) in enumerate(zip(scenes, lengths)):
            if progress:
                progress(round(10 + 62 * idx / len(scenes)), f"Renderizando escena {idx+1}/{len(scenes)}")
            clip = tempdir / f"scene_{idx:03d}.mp4"
            vf = scene_filter(width, height, length, scene.motion, fps)
            frames = round(length * fps)
            cmd_run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-threads", "2", "-i", str(scene.image),
                     "-vf", vf, "-frames:v", str(frames), "-an", "-c:v", "libx264", "-preset", "veryfast",
                     "-crf", "23", "-pix_fmt", "yuv420p", "-r", str(fps), "-movflags", "+faststart", str(clip)], timeout=1200)
            clips.append(clip)

        if progress:
            progress(75, "Componiendo transiciones")
        assembled = tempdir / "assembled.mp4"
        if len(clips) == 1:
            assembled = clips[0]
        elif transition == "cut":
            manifest = tempdir / "clips.txt"
            manifest.write_text("".join("file '" + c.name + "'\n" for c in clips), encoding="utf-8")
            cmd_run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0",
                     "-i", str(manifest), "-c", "copy", str(assembled)], timeout=600)
        else:
            # Each xfade subtracts 0.32 seconds from the joined duration.
            overlap = 0.32
            inputs: list[str] = []
            for clip in clips:
                inputs += ["-i", str(clip)]
            filters = []
            running_duration = lengths[0]
            prev = "[0:v]"
            for k in range(1, len(clips)):
                dest = f"[v{k}]"
                offset = running_duration - overlap
                filters.append(f"{prev}[{k}:v]xfade=transition=fade:duration={overlap}:offset={offset:.4f}{dest}")
                running_duration += lengths[k] - overlap
                prev = dest
            cmd_run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *inputs,
                     "-filter_complex", ";".join(filters), "-map", prev, "-an", "-c:v", "libx264",
                     "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p", str(assembled)], timeout=1200)

        if progress:
            progress(91, "Sincronizando la narración")
        # Video lasts narration length when auto_sync, audio has no embedded subtitles.
        cmd_run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(assembled),
                 "-i", str(audio), "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac",
                 "-b:a", "192k", "-af", "aresample=async=1:first_pts=0,apad", "-shortest", "-movflags", "+faststart",
                 str(output)], timeout=1200)
        if progress:
            progress(100, "Video listo")
        return {"file": str(output), "narration_seconds": round(narration, 3),
                "video_seconds": round(probe_duration(output), 3),
                "scene_durations": [round(n, 3) for n in lengths],
                "resolution": resolution, "transition": transition}
    finally:
        import shutil
        shutil.rmtree(tempdir, ignore_errors=True)
